package com.zznode.opentnms.isearch.otnRouteService.api.model;

import java.util.ArrayList;
import java.util.List;

public class RouteCalculationInputWrapper {

	
	private List<ClusionBean> clusionBean = new ArrayList<ClusionBean>();

	public List<ClusionBean> getClusionBean() {
		return clusionBean;
	}

	public void setClusionBean(List<ClusionBean> clusionBean) {
		this.clusionBean = clusionBean;
	}
	
	
	
	
}
