package com.zznode.opentnms.isearch.otnRouteService.api.model;

public class ClusionBean {

	private String meid;
	private String ptpid;
	
	
	public String getMeid() {
		return meid;
	}
	public void setMeid(String meid) {
		this.meid = meid;
	}
	public String getPtpid() {
		return ptpid;
	}
	public void setPtpid(String ptpid) {
		this.ptpid = ptpid;
	}
	
	

}
